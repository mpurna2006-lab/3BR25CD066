import unittest
from io import StringIO
import sys
import hello

class TestHello(unittest.TestCase):
    def test_main_output(self):
        captured_output = StringIO()
        sys.stdout = captured_output
        hello.main()
        sys.stdout = sys.__stdout__
        self.assertEqual(captured_output.getvalue().strip(), "Hello, World!")

if __name__ == "__main__":
    unittest.main()
