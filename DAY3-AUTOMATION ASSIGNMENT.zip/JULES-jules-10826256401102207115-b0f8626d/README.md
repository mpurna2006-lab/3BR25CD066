# Hello World Project

This repository contains a simple Python "Hello, World!" program and tests.

## Files

- `hello.py`: Python script that prints "Hello, World!".
- `test_hello.py`: Unit tests verifying the output of `hello.py`.

## Usage

To run the Hello World script:

```bash
python3 hello.py
```

To run the unit tests:

```bash
python3 -m unittest test_hello.py
```
